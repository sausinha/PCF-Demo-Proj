package com.service.demo.data.beans;

import java.util.List;

public class CustomerData {
	private List<Customer> customerVOList;

	/**
	 * @return the customerVOList
	 */
	public List<Customer> getCustomerVOList() {
		return customerVOList;
	}

	/**
	 * @param customerVOList
	 *            the customerVOList to set
	 */
	public void setCustomerVOList(List<Customer> customerVOList) {
		this.customerVOList = customerVOList;
	}

}
