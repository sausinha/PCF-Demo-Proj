/**
 * 
 */
package com.service.demo.vo;

import java.io.Serializable;

/**
 * @author ahmshaik
 *
 */
public class BaseRequestVO implements Serializable {
	private static final long serialVersionUID = -1105379690302857471L;

}
