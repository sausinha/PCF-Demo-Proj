package com.service.demo.beans;

import java.io.Serializable;

public class BaseBean implements Serializable {

	private static final long serialVersionUID = 6658594417839147536L;

}
